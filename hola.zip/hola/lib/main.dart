import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter_animate/flutter_animate.dart';


void main() {
  runApp(const PokedexApp());
}

class PokedexApp extends StatelessWidget {
  const PokedexApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false, // Desactiva el banner de depuración
      theme: ThemeData(
        primarySwatch: Colors.blue,
        fontFamily: 'Poppins', // Usa una tipografía llamativa
        brightness: Brightness.light, // Tema claro por defecto
      ),
      darkTheme: ThemeData(
        brightness: Brightness.dark, // Tema oscuro
        primarySwatch: Colors.blue,
      ),
      themeMode: ThemeMode.system, // Usa el modo del sistema (claro/oscuro)
      home: const PokemonListScreen(), // Pantalla principal de la lista de Pokémon
    );
  }
}

class Pokemon {
  final String name;
  final String imageUrl;
  final int id;
  final String type;
  bool isFavorite;

  Pokemon({
    required this.name,
    required this.imageUrl,
    required this.id,
    required this.type,
    this.isFavorite = false,
  });


  factory Pokemon.fromJson(Map<String, dynamic> json, String type) {
    int id = int.parse(json['url'].split('/')[6]);
    return Pokemon(
      name: json['name'],
      imageUrl: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/$id.png',
      id: id,
      type: type,
    );
  }

  // Métodos para manejar favoritos usando SharedPreferences
  static Future<void> saveToFavorites(Pokemon pokemon) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String> favorites = prefs.getStringList('favorites') ?? [];
    favorites.add(pokemon.name);
    await prefs.setStringList('favorites', favorites);
  }

  static Future<bool> isPokemonFavorite(Pokemon pokemon) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String> favorites = prefs.getStringList('favorites') ?? [];
    return favorites.contains(pokemon.name);
  }

  static Future<void> removeFromFavorites(Pokemon pokemon) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String> favorites = prefs.getStringList('favorites') ?? [];
    favorites.remove(pokemon.name);
    await prefs.setStringList('favorites', favorites);
  }
}

class PokemonListScreen extends StatefulWidget {
  const PokemonListScreen({super.key});

  @override
  _PokemonListScreenState createState() => _PokemonListScreenState();
}

class _PokemonListScreenState extends State<PokemonListScreen> {
  List<Pokemon> pokemonList = [];
  List<Pokemon> filteredList = [];
  bool isLoading = true;
  String nextUrl = 'https://pokeapi.co/api/v2/pokemon?limit=200';
  TextEditingController searchController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  bool isGridView = false; // Variable para alternar entre vista de lista o cuadrícula
  final player = AudioPlayer(); // Para reproducir sonidos al interactuar

  // filtro de ordenación Alphabetica
  String sortOption = 'Alphabetically';

  // Filtro por tipo
  String selectedTypeFilter = 'All'; // Filtro de tipo seleccionado
  bool isDarkMode = false; // Alternar entre modo oscuro y claro

  @override
  void initState() {
    super.initState();
    fetchPokemon(); // Cargar los datos de Pokémon
    _scrollController.addListener(() {
      if (_scrollController.position.pixels == _scrollController.position.maxScrollExtent) {
        fetchPokemon(); // Cargar más Pokémon al hacer scroll
      }
    });
  }

  // Método para cargar los Pokémon desde la API
  Future<void> fetchPokemon() async {
    if (nextUrl.isEmpty) return;

    try {
      final response = await http.get(Uri.parse(nextUrl));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        List<Pokemon> tempList = [];
        for (var pokemonData in data['results']) {
          final pokemonResponse = await http.get(Uri.parse(pokemonData['url']));
          if (pokemonResponse.statusCode == 200) {
            final pokemonJson = json.decode(pokemonResponse.body);
            String type = pokemonJson['types'][0]['type']['name'];
            tempList.add(Pokemon.fromJson(pokemonData, type));
          }
        }

        setState(() {
          pokemonList.addAll(tempList);
          filteredList = pokemonList;
          nextUrl = data['next'] ?? '';
          isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        isLoading = false; // Si hay un error, se detiene el loading
      });
    }
  }

  // Método para filtrar la lista de Pokémon por nombre y tipo
  void filterPokemon(String query) {
    setState(() {
      filteredList = pokemonList
          .where((pokemon) =>
      pokemon.name.toLowerCase().contains(query.toLowerCase()) &&
          (selectedTypeFilter == 'All' || pokemon.type == selectedTypeFilter))
          .toList();
    });
  }

  // Alterna entre vista en lista y cuadrícula
  void toggleView() {
    setState(() {
      isGridView = !isGridView;
    });
  }

  // Método para reproducir sonido al hacer tap en un Pokémon
  void playPokemonSound(Pokemon pokemon) {
    player.play(AssetSource('sounds/${pokemon.name.toLowerCase()}.mp3'));
  }

  // Navegar a la pantalla de detalle del Pokémon
  void navigateToDetail(Pokemon pokemon) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => PokemonDetailScreen(pokemon: pokemon),
      ),
    );
  }

  // Mostrar un Pokémon aleatorio
  void randomPokemon() {
    setState(() {
      final randomIndex = (pokemonList..shuffle()).first;
      navigateToDetail(randomIndex);
    });
  }

  // Ordenar la lista de Pokémon Alphabeticamente
  void sortPokemon() {
    setState(() {
      if (sortOption == 'Alphabetically') {
        filteredList.sort((a, b) => a.name.compareTo(b.name));
      } else {
        filteredList.sort((a, b) => a.id.compareTo(b.id));
      }
    });
  }

  // Alternar entre modo oscuro y claro
  void toggleTheme(bool value) {
    setState(() {
      isDarkMode = value;
    });
  }

  // Actualizar el estado de favorito
  void updateFavoriteStatus(Pokemon pokemon) async {
    if (pokemon.isFavorite) {
      await Pokemon.removeFromFavorites(pokemon); // Eliminar de favoritos
    } else {
      await Pokemon.saveToFavorites(pokemon); // Agregar a favoritos
    }
    setState(() {
      pokemon.isFavorite = !pokemon.isFavorite; // Cambiar el estado de favorito
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: isDarkMode ? Colors.grey[900] : Colors.blueAccent, // Cambio de fondo según el modo
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: const Text(
          'Pokedex',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.star),
            onPressed: () {

              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const FavoritesScreen()),
              );
            },
          ),
          IconButton(
            icon: Icon(isGridView ? Icons.view_list : Icons.grid_on),
            onPressed: toggleView, // Alterna entre vista en lista o cuadrícula
          ),
          PopupMenuButton<String>(
            onSelected: (String value) {
              setState(() {
                sortOption = value;
                sortPokemon();
              });
            },
            itemBuilder: (BuildContext context) {
              return ['Alphabetically', 'By Number'].map((String choice) {
                return PopupMenuItem<String>(value: choice, child: Text(choice));
              }).toList();
            },
          ),
          Switch(
            value: isDarkMode,
            onChanged: toggleTheme,
            activeColor: Colors.white, // Color del interruptor
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              controller: searchController,
              decoration: InputDecoration(
                hintText: 'Search',
                filled: true,
                fillColor: Colors.white,
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30),
                  borderSide: BorderSide.none,
                ),
              ),
              onChanged: filterPokemon, // filtrar busqueda de pokemon por nombre
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: DropdownButton<String>(
              value: selectedTypeFilter,
              onChanged: (String? newValue) {
                setState(() {
                  selectedTypeFilter = newValue!;
                  filterPokemon(searchController.text); // filtro de tipos de pokemon
                });
              },
              items: ['All', 'fire', 'water', 'grass', 'electric']
                  .map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(value: value, child: Text(value));
              }).toList(),
            ),
          ),
          Expanded(
            child: isLoading
                ? Center(
              child: CircularProgressIndicator(), // Mostrar cargando mientras se cargan los datos
            )
                : isGridView
                ? GridView.builder(
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 8.0,
                mainAxisSpacing: 8.0,
              ),
              controller: _scrollController,
              padding: const EdgeInsets.all(8.0),
              itemCount: filteredList.length,
              itemBuilder: (context, index) {
                final pokemon = filteredList[index];
                return PokemonCard(
                  pokemon: pokemon,
                  onTap: () {
                    playPokemonSound(pokemon); // Reproducir sonido al tocar un Pokémon
                    navigateToDetail(pokemon);
                  },
                  onFavoriteChanged: updateFavoriteStatus, // Actualizar favorito
                );
              },
            )
                : ListView.builder(
              controller: _scrollController,
              padding: const EdgeInsets.all(8.0),
              itemCount: filteredList.length,
              itemBuilder: (context, index) {
                final pokemon = filteredList[index];
                return PokemonCard(
                  pokemon: pokemon,
                  onTap: () {
                    playPokemonSound(pokemon); // Reproducir sonido al tocar un Pokémon
                    navigateToDetail(pokemon);
                  },
                  onFavoriteChanged: updateFavoriteStatus,
                );
              },
            ),
          ),
          ElevatedButton(
            onPressed: randomPokemon,
            child: const Text(" Pokémon Random"), // Botón para mostrar un Pokémon aleatorio
          ),
        ],
      ),
    );
  }
}

class PokemonCard extends StatelessWidget {
  final Pokemon pokemon;
  final VoidCallback onTap;
  final Function(Pokemon) onFavoriteChanged;

  const PokemonCard({
    Key? key,
    required this.pokemon,
    required this.onTap,
    required this.onFavoriteChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Cambio de color según el tipo de Pokémon
    Color cardColor;
    switch (pokemon.type) {
      case 'fire':
        cardColor = Colors.red;
        break;
      case 'water':
        cardColor = Colors.blue;
        break;
      case 'grass':
        cardColor = Colors.green;
        break;
      default:
        cardColor = Colors.grey;
    }

    return Hero(
      tag: 'pokemon-${pokemon.id}', // Transición suave al detalle del Pokémon
      child: Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        elevation: 4,
        color: cardColor.withOpacity(0.3),
        child: ListTile(
          contentPadding: const EdgeInsets.all(8.0),
          leading: Image.network(
            pokemon.imageUrl,
            height: 30,
            width: 30,
          ),
          title: Text(
            '#${pokemon.id.toString().padLeft(3, '0')}',
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 10,
            ),
          ),
          subtitle: Text(
            pokemon.name.capitalize(),
            style: const TextStyle(fontSize: 10),
          ),
          trailing: IconButton(
            icon: Icon(
              pokemon.isFavorite ? Icons.star : Icons.star_border,
              color: Colors.yellow, // Estrella para marcar favoritos
            ),
            onPressed: () {
              onFavoriteChanged(pokemon); // Cambiar estado de favorito
            },
          ),
          onTap: onTap, // Tocar para ir al detalle del Pokémon
        ),
      ),
    );
  }
}

class PokemonDetailScreen extends StatelessWidget {
  final Pokemon pokemon;

  const PokemonDetailScreen({Key? key, required this.pokemon}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(pokemon.name.capitalize()),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.network(pokemon.imageUrl),
            Text(
              pokemon.name.capitalize(),
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            Text(
              'Type: ${pokemon.type}',
              style: const TextStyle(fontSize: 18),
            ),
          ],
        ),
      ),
    );
  }
}

extension StringCapitalize on String {
  String capitalize() {
    if (this.isEmpty) return this;
    return this[0].toUpperCase() + this.substring(1);
  }
}

class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Favorites"),
      ),
      body: Center(
        child: Text("Favorites will be shown here."),
      ),
    );
  }
}
